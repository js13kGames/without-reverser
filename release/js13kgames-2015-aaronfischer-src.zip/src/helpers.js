class Helper {
    static random_number(min, max) {
        return Math.floor((Math.random() * max) + min);
    }
}
